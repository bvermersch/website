from numpy import *
from pylab import *
import os

Delta = linspace(0.02,2,11)
np = len(Delta)
close('all'), ion(), show()
E,S,EP,SP = [zeros(np) for i in range(4) ]
## EXTRACT THE DATA
for k in range(len(Delta)):
	fname = 'Delta_{:.2f}'.format(Delta[k])
	try:
		R = loadtxt(fname+'/'+fname+'.out')
		E[k] = R[0]
		S[k] = R[1]
		EP[k] = R[2]
		SP[k] = R[3]
	except:
		print('index ', k, ': extraction failed')
### PLOT ##
plot(Delta,E,'-ob',ms=15)
plot(Delta,EP,'-r*',ms=15)
xlabel('$\Delta$')
ylabel('Gap')
l = 'Non QN','QN'
legend(l,loc=0)
figure()
plot(Delta,S,'-ob',ms=15)
plot(Delta,SP,'-r*',ms=15)
xlabel('$\Delta$')
ylabel('Entropy')
legend(l,loc=0)



			
