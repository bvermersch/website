#include "itensor/mps/sites/spinhalfparity.h"
#include "itensor/all.h"

using namespace itensor;

Real Entrop(MPS& psi, const int b)
{
	Real S = 0;
	psi.position(b);
	ITensor A,D,B;
	A = psi.A(b);
	auto spec = svd(psi.A(b)*psi.A(b+1),A,D,B);
	for(int n = 1; n <= spec.numEigsKept(); ++n)
		if (spec.eig(n)>1E-12)
			S += -spec.eig(n)*log(spec.eig(n))/log(2);
	return S;
}
Real Entrop(IQMPS& psi, const int b)
{
	Real S = 0;
	psi.position(b);
	IQTensor A,D,B;
	A = psi.A(b);
	auto spec = svd(psi.A(b)*psi.A(b+1),A,D,B);
	for(int n = 1; n <= spec.numEigsKept(); ++n)
		if (spec.eig(n)>1E-12)
			S += -spec.eig(n)*log(spec.eig(n))/log(2);
	return S;
}

int main(int argc, char* argv[]) 
{
	/// Read input file
	auto input = InputGroup(argv[1],"input");
	auto N = input.getInt("N");
	auto nsweeps = input.getInt("nsweeps");
	auto quiet = input.getYesNo("quiet",true);
	auto table = InputGroup(input,"sweeps");
	auto sweeps = Sweeps(nsweeps,table);
	auto ncut = input.getInt("ncut");
	auto alpha = input.getReal("alpha");
	auto Delta = input.getReal("Delta");
	Real J = 1.;

	auto sites = SpinHalf(N);

	//Long range ising model
	println("MPO construction with ", ncut, " neighbors");
	auto ampo = AutoMPO(sites);
	for(int j = 1; j <= N; ++j)
	{
		ampo += 2.*Delta,"Sz",j;
		for(int k = 1; k <= ncut; ++k)
			if (j+k<=N)
				ampo += 4*J*std::pow(k,-alpha),"Sx",j,"Sx",j+k;
	}
	// MPO CONSTRUCTION WITHOUT QN
	auto H = MPO(ampo);
	// MPO WITH QN
	auto HQ = IQMPO(ampo);
	
	//Eigenstate search for non-conserving QN MPO
	Real penalty = 20;
	auto psi = MPS(sites);
	auto en = dmrg(psi,H,sweeps,{"Quiet=",true});
	auto w = std::vector<MPS>(1);
	w.at(0) = psi;
	auto psi1 = MPS(sites);
	auto en1 = dmrg(psi1,H,w,sweeps,{"Quiet=",true,"Weight=",penalty});
	
	//Eigenstate search conserving QN MPO
	InitState state(sites,"Up");  // Search in the even parity setor
	auto phi = IQMPS(state);
	auto enP = dmrg(phi,HQ,sweeps,{"Quiet=",true});
	state.set(1,"Dn");  // Search in the odd parity sector
	auto phi1 = IQMPS(state);
	auto enP1 = dmrg(phi1,HQ,sweeps,{"Quiet=",true});

	// Printing results
	println("Non QN code");
	println("-----------");
	println("Gap: ",en1-en);
	println("Entropy GS: ",Entrop(psi,N/2));
	println("-----------");
	println(" QN code");
	println("-----------");
	println("Gap : ",enP1-enP);
	println("Entropy GS: ",Entrop(phi,N/2));
	
        // Exporting results
	std::ofstream out(format("Delta_%.2f.out",Delta));
	out << en1-en << std::endl;
	out << Entrop(psi,N/2) << std::endl;
	out << enP1-enP << std::endl;
	out << Entrop(phi,N/2) << std::endl;
	out.close();
	return 0;
}
