from numpy import *
import os


#### PARAMETERS ####
alpha = 3.
ncut = 2 ##Next Nearest neighbor case
N = 40
Delta = arange(0.08,2.08,0.08)
quiet = 'no'
nsweeps = 5
maxm = [100,100,100,200,300]
minm = [20,20,10,10,10]
niter = [2,2,2,2,2]
cutoff = [1E-6,1E-8,1E-12,1E-13,1E-13]
noise = zeros(5)

f0 = os.getcwd()
		
#### SWEEP OVER DELTA ####
for k in range(len(Delta)):
	fname = 'Delta_{:.2f}'.format(Delta[k])
	try:
		os.makedirs(fname)
	except:
		print ('Warning: ', fname,' already exists')
	## WRITING THE INPUT FILE ##
	f = open(fname+'/input.txt','w')
	f.write('input\n')
	f.write('{\n')
	f.write('N = {:d}\n'.format(N))
	f.write('alpha = {:g}\n'.format(alpha))
	f.write('ncut = {:g}\n'.format(ncut))
	f.write('Delta = {:g}\n'.format(Delta[k]))
	f.write('quiet = '+quiet+'\n')
	f.write('nsweeps = {:d}\n'.format(nsweeps))
	f.write('sweeps \n { ')
	f.write('\t maxm \t minm \t cutoff \t niter \t noise\n')
	for r in range(nsweeps):
		f.write('\t {:d} \t {:d} \t {:E} \t {:d} \t {:g} \n'.format(maxm[r],minm[r],cutoff[r],niter[r],noise[r]))
	f.write('\t}\n')
	f.write('}\n')
	f.close()
	#### RUN THE SIMULATION IN THE LOCAL DIRECTORY
	os.chdir(fname)
	os.system("../parityising input.txt")
	os.chdir(f0)


			
